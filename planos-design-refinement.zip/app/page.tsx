import { Card } from "@/components/ui/card"
import { Check } from "lucide-react"

export default function PricingPage() {
  const plans = [
    {
      name: "START",
      period: "MENSAL",
      price: "135",
      cents: "00",
    },
    {
      name: "PRESS",
      period: "TRIMESTRAL",
      price: "113",
      cents: "33",
      installments: "3x",
    },
    {
      name: "CROSS",
      period: "SEMESTRAL",
      price: "99",
      cents: "00",
      installments: "6x",
      blockDays: "Bloqueio de até 35 dias",
    },
    {
      name: "LIGHT",
      period: "SEMESTRAL RECORRENTE",
      price: "102",
      cents: "19",
      note: "PARCELA DESCONTADA NO SEU CARTÃO MENSALMENTE",
    },
    {
      name: "PUMP",
      period: "ANUAL",
      price: "75",
      cents: "00",
      installments: "12x",
      schedule: "HORÁRIO INTERMEDIÁRIO\n05:00 ÀS 15:00 (SEG A QUI)\nSEX A DOM (HORÁRIO LIVRE)",
    },
    {
      name: "UP",
      period: "",
      badge: "HORÁRIO LIVRE",
      benefit: "GANHE UMA AVALIAÇÃO FÍSICA E DESCONTO EM 2 CONSULTAS NUTRICIONAIS",
      blockDays: "Bloqueio de até 100 dias",
      price: "84",
      cents: "90",
      installments: "12x",
      isSpecial: true,
    },
  ]

  return (
    <main className="min-h-screen bg-primary">
      <div className="mx-auto max-w-md md:max-w-4xl lg:max-w-6xl px-3 md:px-6 py-4 md:py-8">
        <h1 className="text-center text-2xl md:text-4xl lg:text-5xl font-black italic text-primary-foreground mb-3 md:mb-6 tracking-wide">
          PLANOS DA BE
        </h1>

        <div className="space-y-2 md:grid md:grid-cols-2 md:gap-4 md:space-y-0 lg:grid-cols-3">
          {plans.map((plan, index) => (
            <Card key={index} className="overflow-hidden border-0 shadow-md py-2.5 md:py-4 md:h-full">
              <div className="p-3 md:p-5 h-full flex flex-col md:py-2.5">
                <div className="flex justify-between gap-2 mb-1.5 items-start md:mb-2.5">
                  <div className="flex-1 min-w-0">
                    <h2 className="text-base md:text-xl lg:text-2xl font-black italic text-primary leading-tight">
                      PLANO {plan.name}
                    </h2>
                    <p className="text-[10px] md:text-xs lg:text-sm font-bold text-foreground uppercase tracking-wide leading-tight">
                      {plan.period}
                    </p>
                  </div>

                  {plan.price && (
                    <div className="flex items-baseline gap-0.5 md:gap-1 shrink-0">
                      {plan.installments && (
                        <span className="text-xs md:text-sm font-black text-primary-foreground bg-primary rounded px-1 md:px-2">
                          {plan.installments}
                        </span>
                      )}
                      <div
                        className={`inline-flex items-baseline ${plan.isSpecial ? "bg-accent" : "bg-primary"} rounded-lg px-2 md:px-3 py-1 md:py-1.5`}
                      >
                        <span className="text-[10px] md:text-sm font-black text-primary-foreground">R$</span>
                        <span className="text-xl md:text-3xl lg:text-4xl font-black text-primary-foreground leading-none">
                          {plan.price}
                        </span>
                        <span className="text-xs md:text-lg font-black text-primary-foreground leading-none">
                          ,{plan.cents}
                        </span>
                      </div>
                    </div>
                  )}
                </div>

                {plan.badge && (
                  <div className="flex items-center gap-1 mb-1 md:mb-2">
                    <Check className="h-3 w-3 md:h-4 md:w-4 text-accent shrink-0" />
                    <span className="text-[10px] md:text-xs font-bold text-foreground uppercase">{plan.badge}</span>
                  </div>
                )}

                {plan.schedule && (
                  <p className="text-[9px] md:text-xs font-semibold text-foreground/80 leading-tight whitespace-pre-line mb-1 md:mb-2">
                    {plan.schedule}
                  </p>
                )}

                {plan.benefit && (
                  <p className="text-[9px] md:text-xs font-semibold text-foreground/80 leading-tight mb-1 md:mb-2">
                    {plan.benefit}
                  </p>
                )}

                {plan.blockDays && (
                  <div className="bg-muted/50 rounded px-2 md:px-3 py-1 md:py-1.5 mb-1 md:mb-2">
                    <p className="text-[9px] md:text-xs font-bold text-foreground/90 leading-tight">
                      ✓ {plan.blockDays}
                    </p>
                  </div>
                )}

                {plan.note && (
                  <p className="text-[9px] md:text-xs text-muted-foreground leading-tight italic">{plan.note}</p>
                )}
              </div>
            </Card>
          ))}
        </div>

        <p className="text-center text-[10px] md:text-sm text-primary-foreground/80 mt-3 md:mt-6 leading-relaxed font-medium">
          Todos os planos incluem acesso à Musculação e Aulas Coletivas
        </p>
      </div>
    </main>
  )
}
