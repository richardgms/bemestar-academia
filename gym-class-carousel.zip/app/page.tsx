import { GymClassCarousel } from "@/components/gym-class-carousel"

export default function Home() {
  return (
    <main className="min-h-screen bg-background">
      <GymClassCarousel />
    </main>
  )
}
