"use client"

import type React from "react"

import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Music, Dumbbell, Bike, PersonStanding, Target, Waves } from "lucide-react"
import { useRef } from "react"

interface GymClass {
  id: string
  icon: React.ReactNode
  title: string
  description: string
  duration: string
}

const gymClasses: GymClass[] = [
  {
    id: "fitdance",
    icon: <Music className="w-8 h-8" />,
    title: "FitDance",
    description: "Queime calorias dançando ao som dos maiores hits! Aula animada pra todos os níveis.",
    duration: "60min",
  },
  {
    id: "bodypump",
    icon: <Dumbbell className="w-8 h-8" />,
    title: "BodyPump",
    description: "Treino de resistência com barras e anilhas. Defina e fortaleça o corpo todo.",
    duration: "60min",
  },
  {
    id: "rpm",
    icon: <Bike className="w-8 h-8" />,
    title: "RPM",
    description: "Ciclismo indoor de alta energia. Pedal forte, música alta e muita queima!",
    duration: "45min",
  },
  {
    id: "yoga",
    icon: <PersonStanding className="w-8 h-8" />,
    title: "Yoga",
    description: "Equilíbrio entre corpo e mente. Flexibilidade, força e relaxamento.",
    duration: "60min",
  },
  {
    id: "crossfit",
    icon: <Target className="w-8 h-8" />,
    title: "CrossFit",
    description: "Treino funcional de alta intensidade. Desenvolva força, resistência e agilidade.",
    duration: "60min",
  },
  {
    id: "natacao",
    icon: <Waves className="w-8 h-8" />,
    title: "Natação",
    description: "Exercício completo de baixo impacto. Trabalha todos os grupos musculares.",
    duration: "60min",
  },
]

export function GymClassCarousel() {
  const scrollContainerRef = useRef<HTMLDivElement>(null)

  return (
    <section className="w-full py-12 px-4">
      <div className="container mx-auto">
        <h2 className="text-3xl font-bold text-center mb-8 text-balance">Nossas Modalidades</h2>

        {/* Mobile: Horizontal Carousel */}
        <div
          ref={scrollContainerRef}
          className="flex gap-4 overflow-x-auto snap-x snap-mandatory scrollbar-hide pb-4 md:hidden"
          style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}
        >
          {gymClasses.map((gymClass) => (
            <div key={gymClass.id} className="flex-none w-[85vw] snap-center">
              <GymClassCard {...gymClass} />
            </div>
          ))}
        </div>

        {/* Desktop: Grid Layout */}
        <div className="hidden md:grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {gymClasses.map((gymClass) => (
            <GymClassCard key={gymClass.id} {...gymClass} />
          ))}
        </div>

        {/* Scroll Indicator for Mobile */}
        <div className="flex justify-center gap-2 mt-4 md:hidden">
          {gymClasses.map((_, index) => (
            <button
              key={index}
              className="w-2 h-2 rounded-full bg-muted hover:bg-[#FF6B35] transition-colors"
              onClick={() => {
                const container = scrollContainerRef.current
                if (container) {
                  const cardWidth = container.scrollWidth / gymClasses.length
                  container.scrollTo({
                    left: cardWidth * index,
                    behavior: "smooth",
                  })
                }
              }}
              aria-label={`Ir para card ${index + 1}`}
            />
          ))}
        </div>
      </div>
    </section>
  )
}

function GymClassCard({ icon, title, description, duration }: Omit<GymClass, "id">) {
  return (
    <Card className="relative overflow-hidden border-0 shadow-lg bg-white h-full flex flex-col">
      {/* Orange top border */}
      <div className="absolute top-0 left-0 right-0 h-1.5 bg-[#FF6B35]" />

      <div className="p-6 flex flex-col h-full">
        {/* Header with icon and duration */}
        <div className="flex items-start justify-between mb-6">
          <div className="bg-[#FFF0EB] rounded-2xl p-4 text-[#FF6B35]">{icon}</div>
          <span className="text-muted-foreground font-medium">{duration}</span>
        </div>

        {/* Content */}
        <div className="flex-1 flex flex-col">
          <h3 className="text-2xl font-bold mb-3 text-foreground">{title}</h3>
          <p className="text-muted-foreground leading-relaxed mb-6 flex-1">{description}</p>

          {/* CTA Button */}
          <Button
            variant="ghost"
            className="text-[#FF6B35] font-bold hover:bg-[#FFF0EB] hover:text-[#FF6B35] w-fit px-0"
          >
            VER HORÁRIOS
          </Button>
        </div>
      </div>
    </Card>
  )
}
